import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


@Component({
  selector: 'app-buy-token',
  templateUrl: './buy-token.component.html',
  styles:[`
      .dropdown {
        height: 50px;
        padding: 10px;
        border: 0;
        font-size: 15px;
        width: 200px;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
}
        `],
  styleUrls: ['./buy-token.component.css']
})



export class BuyTokenComponent implements OnInit  {
  
  ////tokensUsed: any[] = [];
  items : any;
  tokenId: any;
  tokenAddress: string = "";
  records: any;
  
   headers= new HttpHeaders()
      .set('content-type', 'application/json')
      .set('X-API-Key', 'lMp8i9xNPuqQ2k7A31l78dpGKwa7UyXDA1s1fv6sTfF6uLiGRbOI8C2YTLRP6PaD')
      .set('Access-Control-Allow-Origin', '*');
  
  closeResult = '';
  
  constructor(private modalService: NgbModal,private http: HttpClient) {}

  ngOnInit() {     
    }

fetchWallet() {    
  // alert( 'Hello ' + '\nWelcome to C# Corner \nFunction in First Component'); 
   //debugger;
  this.tokenId = this.tokenAddress;
  this.http.get('https://deep-index.moralis.io/api/v2/'+this.tokenId+'/erc20?chain=bsc%20testnet',
     { 'headers': this.headers }
  ).subscribe(data => {
    this.items =data;
      //this.items = this.records
      console.log("records"+this.items)      
    })

   // content.dismiss('Cross click')
}  

  open(content: any) {
    this.modalService.open(content,
   {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = 
         `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}


